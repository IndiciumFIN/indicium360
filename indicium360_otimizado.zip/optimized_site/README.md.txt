# Indicium360 - Website Otimizado

## Estrutura de Arquivos

```
dist/
├── index.html          # HTML minificado
├── assets/
│   ├── styles.min.css  # CSS minificado
│   ├── scripts.js      # JavaScript otimizado
│   └── images/         # Imagens otimizadas
├── site.webmanifest    # Manifest PWA
├── sitemap.xml         # Sitemap para SEO
├── robots.txt          # Robots.txt para SEO
└── .htaccess          # Configurações do servidor
```

## Recursos Implementados

### Acessibilidade
- Menu de acessibilidade completo e responsivo
- Suporte a leitores de tela
- Navegação por teclado
- Contraste ajustável
- Fontes para dislexia
- Zoom e ampliação
- Filtros para daltonismo

### Performance
- CSS minificado e separado
- JavaScript otimizado
- HTML comprimido
- Configurações de cache
- Compressão GZIP

### SEO
- Meta tags otimizadas
- Dados estruturados
- Sitemap XML
- Robots.txt
- Open Graph e Twitter Cards

### Segurança
- Content Security Policy
- Cabeçalhos de segurança
- Validação de formulários

## Instruções de Deploy

1. Faça upload de todos os arquivos da pasta `dist/` para o servidor
2. Configure o servidor web para usar o arquivo `.htaccess`
3. Verifique se as imagens estão na pasta `assets/images/`
4. Teste a funcionalidade do menu de acessibilidade

## Compatibilidade

- Navegadores modernos (Chrome, Firefox, Safari, Edge)
- Dispositivos móveis e tablets
- Leitores de tela (NVDA, JAWS, VoiceOver)
- Conformidade WCAG 2.1 AA/AAA
